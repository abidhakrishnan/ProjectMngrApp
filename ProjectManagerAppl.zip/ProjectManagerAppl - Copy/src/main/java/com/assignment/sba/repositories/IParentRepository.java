package com.assignment.sba.repositories;
import org.springframework.data.jpa.repository.JpaRepository;

import com.assignment.sba.entities.Parent;

public interface IParentRepository extends JpaRepository<Parent, Integer>{

}

